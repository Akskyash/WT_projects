﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MarketProject
{
    public partial class ProductForm : Form
    {
        public ProductForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asifa\Documents\marketdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void fillcombo()
        {
            con.Open();
            SqlCommand comd = new SqlCommand("select CatName from CategoryTable", con);
            SqlDataReader sdr;
            sdr = comd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CatName", typeof(string));
            dt.Load(sdr);
            Catcb.ValueMember = "catName";
            Catcb.DataSource = dt;
            comboBox2.ValueMember = "catName";
            comboBox2.DataSource = dt;
            con.Close();
        }
        private void ProductForm_Load(object sender, EventArgs e)
        {
            fillcombo();
            connect();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CategoryForm cat = new CategoryForm();
            cat.Show();
            this.Hide();
        }
        private void connect()
        {
            con.Open();
            string query = "select * from ProductTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder sb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ProdDG.DataSource = ds.Tables[0];
            con.Close();
        }       

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();                           
                string query = "insert into ProductTable values(" + Prodid.Text + ",'" + ProdName.Text + "','" + ProdQty.Text + "','" +ProdPrice.Text+ "','"+Catcb.SelectedValue.ToString()+"')";
                SqlCommand comd = new SqlCommand(query, con);               
                comd.ExecuteNonQuery();               
                MessageBox.Show("Product Added");
                con.Close();
                connect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Prodid.Text = ProdDG.Rows[e.RowIndex].Cells[0].Value.ToString();
            ProdName.Text = ProdDG.Rows[e.RowIndex].Cells[1].Value.ToString();
            ProdQty.Text = ProdDG.Rows[e.RowIndex].Cells[2].Value.ToString();
            ProdPrice.Text = ProdDG.Rows[e.RowIndex].Cells[3].Value.ToString();
            Catcb.SelectedValue = ProdDG.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (Prodid.Text == "")
                {
                    MessageBox.Show("Select the product to be deleted");

                }
                else
                {
                    con.Open();
                    string query = "delete from ProductTable where Prodid= " + Prodid.Text + "";
                    SqlCommand comd = new SqlCommand(query, con);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Product Deleted");
                    con.Close();
                    connect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (ProdName.Text == "" || Catcb.SelectedIndex == -1 || ProdQty.Text == "" || ProdPrice.Text == "")
            {
                MessageBox.Show("Information Missing");
            }
            else
            {


                try
                {
                    con.Open();
                    SqlCommand comd = new SqlCommand("update ProductTable set ProdName=@PN,ProdQty=@PQT,ProdPrice=@PP,ProdCat=@PC where Prodid=@PKey", con);
                    // SqlCommand comd = new SqlCommand("update ProductTable set ProdName='" + ProdName.Text + "',ProdQty='" + ProdQty.Text + ",ProdPrice=" + ProdPrice.Text + "'", con);
                    //  string query = "update ProductTable set ProdName='" + ProdName.Text + "',ProdQty='" + ProdQty.Text + ",ProdPrice=" + ProdPrice.Text + "',ProdCat = '" + Catcb.SelectedValue.ToString() + "' where Prodid=" + Prodid.Text + ";";
                    comd.Parameters.AddWithValue("@PN", ProdName.Text);
                    comd.Parameters.AddWithValue("@PQT", ProdQty.Text);   // ProdCat=@PC
                    comd.Parameters.AddWithValue("@PP", ProdPrice.Text);
                    comd.Parameters.AddWithValue("@PC", Catcb.SelectedItem.ToString());
                    comd.Parameters.AddWithValue("@PKey", Prodid.Text);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Product Editted");
                    con.Close();
                    connect();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SellerForm sf = new SellerForm();
            sf.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            connect();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            con.Open();
            string query = "select * from ProductTable where ProdCat='" + comboBox2.SelectedValue.ToString() + "';";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ProdDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm log = new LoginForm();
            log.Show();
        }
    }
}
