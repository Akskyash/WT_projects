﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MarketProject
{
    public partial class SellerForm : Form
    {
        public SellerForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asifa\Documents\marketdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void button1_Click(object sender, EventArgs e)
        {
            ProductForm prod = new ProductForm();
            prod.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CategoryForm cat = new CategoryForm();
            cat.Show();
            this.Hide();
        }
        private void connect()
        {
            con.Open();
            string query = "select * from SellerTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder sb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SellerDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "insert into SellerTable values(" + Sellerid.Text + ",'" + SellerName.Text + "','" + SellerAge.Text + "','" + SellerPhone.Text + "','" + SellerPass.Text +"')";
                SqlCommand comd = new SqlCommand(query, con);
                comd.ExecuteNonQuery();
                MessageBox.Show("Seller Added");
                con.Close();
                connect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SellerDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Sellerid.Text = SellerDG.Rows[e.RowIndex].Cells[0].Value.ToString();
            SellerName.Text = SellerDG.Rows[e.RowIndex].Cells[1].Value.ToString();
            SellerAge.Text = SellerDG.Rows[e.RowIndex].Cells[2].Value.ToString();
            SellerPhone.Text = SellerDG.Rows[e.RowIndex].Cells[3].Value.ToString();
            SellerPass.Text = SellerDG.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void SellerForm_Load(object sender, EventArgs e)
        {
            connect();             
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (Sellerid.Text == "")
                {
                    MessageBox.Show("Select the Seller/Customer to be deleted");

                }
                else
                {
                    con.Open();
                    string query = "delete from SellerTable where Sellerid= " + Sellerid.Text + "";
                    SqlCommand comd = new SqlCommand(query, con);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Seller/Customer Deleted");
                    con.Close();
                    connect();
                    Sellerid.Text = "";
                    SellerName.Text = "";
                    SellerAge.Text = "";
                    SellerPhone.Text = "";
                    SellerPass.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if ( SellerName.Text == "" || SellerAge.Text == "" || SellerPhone.Text == "" || SellerPass.Text == "")
                {
                    MessageBox.Show("Information Missing");
                }
                else
                {
                    con.Open();
                    // string query = "update SellerTable set SellerName='" + SellerName.Text + "',SellerAge='" + SellerAge.Text + ",SellerPhone=" + SellerPhone.Text + "',SellerPass= '" + SellerPass.Text + "' where Sellerid=" + Sellerid.Text + ";";
                    // SqlCommand comd = new SqlCommand(query, con);
                    // SqlCommand comd = new SqlCommand("update ProductTable set ProdName=@PN,ProdQty=@PQT,ProdPrice=@PP,ProdCat=@PC where Prodid=@PKey", con);
                    SqlCommand comd = new SqlCommand("update SellerTable set SellerName=@SN,SellerAge=@SA,SellerPhone=@SP,SellerPass=@SPD where Sellerid=@SKey", con);
                    comd.Parameters.AddWithValue("@SN", SellerName.Text);
                    comd.Parameters.AddWithValue("@SA", SellerAge.Text);
                    comd.Parameters.AddWithValue("@SP", SellerPhone.Text);
                    comd.Parameters.AddWithValue("@SPD", SellerPass.Text);
                    comd.Parameters.AddWithValue("@SKey", Sellerid.Text);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Salesman Editted");
                    con.Close();
                    connect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm log = new LoginForm();
            log.Show();
        }
    }
}
