﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MarketProject
{
    public partial class CategoryForm : Form
    {
        public CategoryForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asifa\Documents\marketdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "insert into CategoryTable values(" + CatidTable.Text + ",'" + CatNameTable.Text + "','" + CatDescTable.Text + "')";
                SqlCommand comd = new SqlCommand(query, con);
                comd.ExecuteNonQuery();
                MessageBox.Show("Category Added");
                con.Close();
                connect();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void connect()
        {
            con.Open();
            string query = "select * from CategoryTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder sb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CatDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void CategoryForm_Load(object sender, EventArgs e)
        {
            connect();
        }
        private void CatDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CatidTable.Text = CatDG.Rows[e.RowIndex].Cells[0].Value.ToString();
            CatNameTable.Text = CatDG.Rows[e.RowIndex].Cells[1].Value.ToString();
            CatDescTable.Text = CatDG.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if(CatidTable.Text == "")
                {
                    MessageBox.Show("Select the category to be deleted");

                }
                else
                {
                    con.Open();
                    string query = "delete from CategoryTable where Catid= " + CatidTable.Text + "";
                    SqlCommand comd = new SqlCommand(query, con);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Category Deleted");
                    con.Close();
                    connect();
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (CatidTable.Text == "" || CatNameTable.Text == "" || CatDescTable.Text == "")
                {
                    MessageBox.Show("Information Missing");
                }
                else
                {
                    con.Open();
                    string query = "update CategoryTable set CatName='" + CatNameTable.Text + "',CatDesc='" + CatDescTable.Text + "' where Catid=" + CatidTable.Text + ";";
                    SqlCommand comd = new SqlCommand(query, con);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Category Editted");
                    con.Close();
                    connect();
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProductForm prod = new ProductForm();
            prod.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SellerForm sf = new SellerForm();
            sf.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm log = new LoginForm();
            log.Show();
        }
    }
}
