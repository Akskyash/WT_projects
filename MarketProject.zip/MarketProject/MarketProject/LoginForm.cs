﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MarketProject
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        public static string sellername = "";

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asifa\Documents\marketdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void button1_Click(object sender, EventArgs e)
        {
            if(unametb.Text=="" || passtb.Text == "")
            {
                MessageBox.Show("Enter the username and password");
            }
            else
            {
                if (rolecb.SelectedIndex > -1)
                {

                    if (rolecb.SelectedItem.ToString() == "ADMIN")
                    {
                        if (unametb.Text == "Admin" && passtb.Text == "Admin")
                        {
                            ProductForm prod = new ProductForm();
                            prod.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("If you are Admin then Enter the correct Name and Password");
                        }
                    }
                    else
                    {
                        // MessageBox.Show("You are in the seller section");
                        con.Open();
                        SqlDataAdapter sda = new SqlDataAdapter("select count(20) from SellerTable where SellerName='" + unametb.Text + "'and SellerPass='" + passtb.Text + "'", con);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        if(dt.Rows[0][0].ToString()== "1")
                        {
                            sellername = unametb.Text;
                            SellingForm sf = new SellingForm();
                            sf.Show();
                            this.Hide();
                            con.Close();
                        }
                        else
                        {
                            MessageBox.Show("Wrong username or password");
                        }
                        con.Close();
                    }
                   
                }
                else
                {
                    MessageBox.Show("Select a Role");
                }                                                              
            }
        }

        private void rolecb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void unametb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
