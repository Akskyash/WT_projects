﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MarketProject
{
    public partial class SellingForm : Form
    {
        public SellingForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asifa\Documents\marketdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void fillcombo()
        {
            con.Open();
            SqlCommand comd = new SqlCommand("select CatName from CategoryTable", con);
            SqlDataReader sdr;
            sdr = comd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CatName", typeof(string));
            dt.Load(sdr);
          //Catcb.ValueMember = "catName";
          //Catcb.DataSource = dt;
            comboBox2.ValueMember = "catName";
            comboBox2.DataSource = dt;
            con.Close();
        }
        private void connect()
        {
            con.Open();
            string query = "select ProdName, ProdPrice from ProductTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder sb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            psDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void Bills()
        {
            con.Open();
            string query = "select * from BillTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder sb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            BillDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void SellingForm_Load(object sender, EventArgs e)
        {
            connect();
            Bills();
            fillcombo();
            SellerNamel.Text = LoginForm.sellername;
            
        }
        

        private void psDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProdName.Text = psDG.Rows[e.RowIndex].Cells[0].Value.ToString();
            ProdPrice.Text = psDG.Rows[e.RowIndex].Cells[1].Value.ToString();
            //Catcb.SelectedValue = ProDG.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Datel.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();

        }      

        private void button4_Click(object sender, EventArgs e)
        {
            if (Billid.Text == "")
            {
                MessageBox.Show("Bill ID is missing");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into BillTable values(" + Billid.Text + ",'" + SellerNamel.Text + "','" + Datel.Text + "'," + Amountl.Text + ")";
                    SqlCommand comd = new SqlCommand(query, con);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Seller Order Added");
                    con.Close();
                    Bills();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void BillDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }      

        private void button7_Click(object sender, EventArgs e)
        {
            connect();
        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            con.Open();
            string query = "select ProdName, ProdPrice from ProductTable where ProdCat='" + comboBox2.SelectedValue.ToString() + "';";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            psDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm log = new LoginForm();
            log.Show();
        }

        

        private void Amountl_Click(object sender, EventArgs e)
        {

        }
        int n = 0, GrandTotal = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            if (ProdName.Text == "" || ProdPrice.Text == "")
            {
                MessageBox.Show("Information Missing");
            }
            else
            {
                int Total = Convert.ToInt32(ProdPrice.Text) * Convert.ToInt32(ProdQty.Text);
                DataGridViewRow nRow = new DataGridViewRow();
                nRow.CreateCells(OrderDG);
                nRow.Cells[0].Value = n + 1;
                nRow.Cells[1].Value = ProdName.Text;
                nRow.Cells[2].Value = ProdPrice.Text;
                nRow.Cells[3].Value = ProdQty.Text;
                nRow.Cells[4].Value = Convert.ToInt32(ProdPrice.Text) * Convert.ToInt32(ProdQty.Text);
                OrderDG.Rows.Add(nRow);
                n++;
                GrandTotal = GrandTotal + Total;
                Amountl.Text = " " + GrandTotal;
            }

        }
    }
}
