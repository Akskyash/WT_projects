<?php
$nameErr=$unameErr=$emailErr=$numberErr=$GenderErr=$passwordErr= $confirmpasswordErr=$fileUpErr="";
$name=$uname=$email=$number=$password= $confirmpassword="";
if(isset($_POST["Signup"])){
$name = $_POST["Name"];
if(empty("Name"))

$name= $_POST['Name']; 

    if(empty($name) || strlen($name)<2)
{
    $nameErr="Enter Name ehich must be at least 2 Characters ";
}
else{
    $nameErr="you have entered your name";
}

echo "<br>";
$uname= $_POST["uname"];
if(empty($uname) || strlen($uname)<4)
{
    $unameErr="Username must be 4 characters";
}
else{
    $unameErr="You have entered your user name";
}
echo "<br>";

$email = $_POST["Email"];
if(empty($email) || !preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email))
{
    $emailErr= "Please enter valid email";
}
else{

    $emailErr= "you have entered valid email";
}

echo "<br>";
$number = $_POST["PhoneNo"]; 
if(is_numeric($number))
{

    $numberErr="You have entered phone number";
}
else{
    $numberErr= "enter phone number";
}

echo "<br>";

if(isset($_POST["Gender"]))
{

    $GenderErr= "You selected gender";
}
else{
    $GenderErr= "Please select your gender";
}

echo "<br>";

$password= $_POST["password"]; 
$confirmpassword=$_REQUEST["confirmpassword"];

        if(empty($password) || strlen($password)<6)
        {
            $passwordErr=  "Please enter a valid password";
        }
        else if($password != $confirmpassword)
        {
            $passwordErr= "Password didn't match";
        }
        else
        {
            $passwordErr= "Password is valid";
        }
        if(move_uploaded_file($_FILES["myfile"]["tmp_name"], "../upload/".$_FILES["myfile"]["name"]))
         {
            $fileUpErr= "File is Uploaded";
         }
         else
         {
            $fileUpErr= "File Cannot be Uploaded";
         }

        $formdata = array(
            'uname'=>$_POST['uname'],
            'Name'=> $_POST["Name"],
            'Email'=>$_POST['Email'],
            'Gender'=> $_POST["Gender"],
            'PhoneNo'=> $_POST["PhoneNo"],
            'password'=>$_POST['password'],
            'filename'=>$_FILES["myfile"]["name"] 
         );
         $existingdata = file_get_contents('Buyerdata.json');
         
         $tempJSONdata = json_decode($existingdata);

         $tempJSONdata[] =$formdata;
        
         $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
         
        
         if(file_put_contents("Buyerdata.json", $jsondata)) {
              echo "Data successfully Saved ";
              echo "<br>";
              echo "You can Login Now";
              echo "<html> <a href='../view/sellerlogin.php'> Click Here </a> </html>";
        
          }
         else 
         {
              echo "No data is saved";
         }
         

}
?>
