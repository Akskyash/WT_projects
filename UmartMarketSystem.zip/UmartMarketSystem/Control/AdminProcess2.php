<?php
session_start();

$data = file_get_contents('AdminData.json');
$mydata = json_decode($data);


if(isset($_POST["Login"]))

{
     foreach($mydata as  $key => $udata)
     {
     
                    
               if($udata->uname==$_POST["uname"] && $udata->password==$_POST["pass"])
               {

                    $_SESSION["uname"]=$_POST["uname"];
                    $_SESSION["password"]=$_POST["pass"];
                    header("location: ../View/AdminProfile.php");
               }     
     }
     

     echo "<h1>Your username or password is incorrect !<h1>";
          
}

?>