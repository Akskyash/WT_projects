<?php
$nameErr=$unameErr=$emailErr=$numberErr=$GenderErr=$passwordErr= $confirmpasswordErr=$fileUpErr="";
$name=$uname=$email=$number=$password= $confirmpassword="";
$hasError = 0;
if(isset($_POST["Signup"])){
$name = $_POST["Name"];
if(empty("Name"))

$name= $_POST['Name']; 

    if(empty($name) || strlen($name)<2)
{
    $hasError = 1;
    $nameErr="Enter Name ehich must be at least 2 Characters ";
}
else{
    $nameErr="You have entered your name";
}

echo "<br>";
$uname= $_POST["uname"];
if(empty($uname) || strlen($uname)<4)
{
    $hasError = 1;
    $unameErr="Username must be 4 characters";
}
else{
    $unameErr="You have entered your user name";
}
echo "<br>";

$email = $_POST["Email"];
if(empty($email) || !preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email))
{
    $hasError = 1;
    $emailErr= "Please enter valid email";
}
else{

    $emailErr= "you have entered valid email";
}

echo "<br>";
$number = $_POST["PhoneNo"]; 
if(is_numeric($number))
{

    $numberErr="You have entered phone number";
}
else{
    $hasError = 1;
    $numberErr= "enter phone number";
}

echo "<br>";

if(isset($_POST["Gender"]))
{

    $GenderErr= "You selected gender";
}
else{
    $hasError = 1;
    $GenderErr= "Please select your gender";
}

echo "<br>";

$password= $_POST["password"]; 
$confirmpassword=$_REQUEST["confirmpassword"];

        if(empty($password) || strlen($password)<6)
        {
            $hasError = 1;
            $passwordErr=  "Please enter a valid password";
        }
        else if($password != $confirmpassword)
        {
            $passwordErr= "Password didn't match";
        }
        else
        {
            $passwordErr= "Password is valid";
        }
        if(move_uploaded_file($_FILES["myfile"]["tmp_name"], "../Upload/".$_FILES["myfile"]["name"]))
         {
            $fileUpErr= "File is Uploaded";
         }
         else
         {
            $hasError = 1;
            $fileUpErr= "File Cannot be Uploaded";
         }


         if($hasError==0)
         {

        $formdata = array(
            'uname'=>$_POST['uname'],
            'Name'=> $_POST["Name"],
            'Email'=>$_POST['Email'],
            'Gender'=> $_POST["Gender"],
            'PhoneNo'=> $_POST["PhoneNo"],
            'password'=>$_POST['password'],
            'filename'=>$_FILES["myfile"]["name"] 
         );
         $existingdata = file_get_contents('AdminData.json');
         
         $tempJSONdata = json_decode($existingdata);

         $tempJSONdata[] =$formdata;
        
         $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
        
         
        
         if(file_put_contents("AdminData.json", $jsondata)) {
              echo "Data successfully Saved ";
              echo "<br>";
              echo "You can Login Now";
              echo "<html> <a href='../View/AdminLogin.php'> Click Here </a> </html>";
        
          }
         else 
         {
              echo "No data is saved";
         }
        }

}
?>
