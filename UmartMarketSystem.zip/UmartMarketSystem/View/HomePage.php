<html>
    <head>
        <title>Home Page</title>
</head>
<body>
  <img src="../Image/Logo.png" width="120" height="100">

<form action= "../Control/Process.php" method="POST">
    <table>
    
    <td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td>
        <td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><h1>Umart Ecommerce Management System</h1></td></td>
</td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td>
</td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td></td>

        <tr><td><td><td><td><td><td><td><td><td><td><a href = "../View/AdminRegistration.php"><br><h2>Admin</h2></br></a>
        <td><td><td><td><td><td><td><td><td><td><td><td><td>

        <td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><a href = "../View/ManagerPage.php"><br><h2>Manager</h2></br></a>

        <td><td><td><td><td><td><td><td><td><td><td><td><td><td><td><a href = "../View/BuyerPage.php"><br><h2>Buyer</h2></br></a>
        <td><td><td><td><td><td><td><td><td><td><td>

        <td><td><td><td><td><td><td><td><td><td><td><a href = "../View/SellerPage.php"><br><h2>Seller</h2></br></a>
    

</table>
</form>

<img src="../Image/Pic5.jpeg" width="400" height="400">
<img src="../Image/Pic2.png" width="400" height="400">
<img src="../Image/Pic6.jpg" width="400" height="400">

</body>
</html>