<?php
session_start();


if(!isset($_SESSION["uname"]))
{
    header("location:../View/AdminLogin.php");
}
?>

<html>
<body>
   <H1> Hi, <?php echo $_SESSION["uname"]; ?> <br> </H1>
   <H2> Click here to logout <a href="../View/AdminLogin.php"> Logout </a> </H2> <br> <br> <br>
</body>
</html>