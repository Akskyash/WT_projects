<?php
include "../control/managerregcheck.php";
?>

<?php
setcookie("user_detect2","visited", time()+86400*30,"/");
echo "<br>";
if(isset($_COOKIE["user_detect2"]))

{
  echo " before come here";
}
else{
  echo "1st time yah";
}
?>

<html>
    <center>
<head>
</head>

<hr>

    <table>
    
    <h1> Sign Up for Seller </h1>
        
    

    <form action="" method="post" enctype="multipart/form-data">
 
        
        <tr><td>Name: </td>
        <td> <input type="text" name="Name"> </td>
        <td> <?php echo $nameErr ?> </td> </tr>

        <tr><td>User name: </td>
        <td> <input type="text" name="uname"> </td>
        <td> <?php echo $unameErr ?> </td> </tr>

        <tr><td>Email: </td>
        <td><input type="text" name="Email"> </td>
        <td><?php echo $emailErr ?> </td> </tr>

        <tr><td>  Phone Number:</td>
        <td><input type="text" name="PhoneNo"> </td>
        <td><?php echo $numberErr ?></td></tr>

        <tr><td>  age:</td>
        <td><input type="text" name="age"> </td>
        <td><?php echo $aErr ?></td></tr>

        <tr><td>  NID:</td>
        <td><input type="text" name="nid"> </td>
        <td><?php echo $nErr ?></td></tr>

        <tr><td>  Pick your Gender: </td>
        <td><input type="radio" name="Gender" value="Male">Male
        <input type="radio" name="Gender" value="Female">Female
        <input type="radio" name="Gender" value="Others">Others</td>
        <td><?php echo $GenderErr ?></td></tr>

        <tr><td>  Password: </td>
        <td><input type="password" name="password" placeholder="Password must be 6 characters"> </td>
        <td><?php echo $passwordErr ?></td></tr>

        <tr><td>   Re-enter password: </td>
        <td><input type="password" name="confirmpassword" placeholder="Please re-enter password"></td>
        <td><?php echo $confirmpasswordErr ?></td></tr>

        <tr><td> Upload your CV copy </td>
        <tr><td> Please choose a file </td>
        <td> <input type="file" name="myfile" > </td>
        <td> <?php echo $fileUpErr ?> </td></tr>

        <tr><td><input type="submit" name="Signup" value="Signup">
        <input type="reset" value="Reset"> </td></td></tr>
        
        <tr><td> Already Have an account? <a href= "../view/managerlogin.php"> Sign in </a>
      </td> </tr>



</table>
</form>
</center>
</html>


