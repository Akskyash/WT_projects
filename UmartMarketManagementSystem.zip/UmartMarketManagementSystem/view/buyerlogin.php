<?php
include "../control/buyerlogincheck.php";
?>

<?php

setcookie("user_detect","visited", time()+86400*30,"/");

if(isset($_COOKIE["user_detect"]))

{
    echo "You have visited me before";
  }
  else{
    echo "You are visiting me for the first time";
  }
?>
<html>

    <head>

</head>
<hr>
<fieldset>
<center>
    <table>
 
    <h1> Login your account </h1>

    <form action= "" method="post">
        <tr>
        <td>User name:</td>
        <td><input type="text" name="uname"></td>
        
</tr>


<tr>
        <td>Password:</td>
        <td> <input type="password" name="pass"  ></td>
       
</tr>

<tr><td>
<input type="submit" name="Login" value="Login">
<input type="reset" value="Reset"> </td></td></tr>
<tr><td>Don't have an account? <a href="../view/buyerReg.php"> Sign Up </a> </td></tr>


</table>
</center>
</form>

</html>

