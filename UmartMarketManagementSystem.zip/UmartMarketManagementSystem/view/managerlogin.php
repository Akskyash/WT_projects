<?php
include "../control/managerlogincheck.php";
?>

<?php

setcookie("user_detect","visited", time()+86400*30,"/");

if(isset($_COOKIE["user_detect"]))

{
    echo "You have visited me before";
  }
  else{
    echo " first time";
  }
?>
<html>
    <center>

    <head>

</head>
<hr>
    <table>
 
    <h1> Login your account </h1>

    <form action= "" method="post">
        <tr>
        <td>User name:</td>
        <td><input type="text" name="uname"></td>
        
</tr>


<tr>
        <td>Password:</td>
        <td> <input type="password" name="pass"  ></td>
       
</tr>

<tr><td>
<input type="submit" name="Login" value="Login">
<input type="reset" value="Reset"> </td></td></tr>
<tr><td>Don't have an account? <a href="../view/managerreg.php"> Sign Up </a> </td></tr>

<input type="image" src="../image/Pic3.jfif" height="300" width="500" >


</table>
</form>
</center>

</html>

