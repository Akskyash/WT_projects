<html>
<img src="../image/Logo.png" width="120" height="100">
  <center>
    <head>
        <title>Home Page</title>
</head>
<body>
    <table>   
      <td>><h1>Umart Ecommerce Management System</h1></td>

        <tr><td><a href = "../view/adminlogin.php"><br><h2>Admin</h2></a><input type="image" src="../image/admin.jpg" height="150" width="150" ></br>
        <td><a href = "../view/managerlogin.php"><br><h2>Manager</h2></a><input type="image" src="../image/manager.jpg" height="150" width="150" ></br></tr>
        <tr><td><a href = "../view/buyerlogin.php"><br><h2>Buyer</h2></a><input type="image" src="../image/buyer.jpg" height="150" width="150" ></br>
        <td><a href = "../view/sellerlogin.php"><br><h2>Seller</h2></a><input type="image" src="../image/seller.jpg" height="150" width="150" ></br></tr>
        
</table>
</form>
</body>
</center> 
</html>
