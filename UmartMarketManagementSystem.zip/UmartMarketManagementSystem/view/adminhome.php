<?php
include("../control/adminsession.php");
?>
<html>
    <center>
<head>
    <title>"Admin Home"</title>
</head>
<body>
    <h2>"ADMIN"</h2><hr>
       <br><a href="../control/adminlogout.php" name ="Logout"><h1>Logout</h1></a></br>          
       <img src="../image/Pic2.png" width="1400" height="400">
</body>
</center>
</html>