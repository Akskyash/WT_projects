<?php
$nameErr=$unameErr=$emailErr=$numberErr=$aErr=$nErr=$GenderErr=$passwordErr= $confirmpasswordErr=$fileUpErr="";
$name=$uname=$email=$number=$age=$nid=$password= $confirmpassword="";
if(isset($_REQUEST["Signup"])){
$name = $_REQUEST["Name"];
if(empty("Name"))

$name= $_REQUEST['Name']; 

    if(empty($name) || strlen($name)<2)
{
    $nameErr="Enter Name ehich must be at least 2 Characters ";
}
else{
    $nameErr="you have entered your name";
}

echo "<br>";
$uname= $_REQUEST["uname"];
if(empty($uname) || strlen($uname)<4)
{
    $unameErr="Username must be 4 characters";
}
else{
    $unameErr="You have entered your user name";
}
echo "<br>";

$email = $_REQUEST["Email"];
if(empty($email) || !preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email))
{
    $emailErr= "Please enter valid email";
}
else{

    $emailErr= "you have entered valid email";
}

echo "<br>";
$number = $_REQUEST["PhoneNo"]; 
if(is_numeric($number))
{

    $numberErr="You have entered phone number";
}
else{
    $numberErr= "enter phone number";
}

echo "<br>";
$age = $_REQUEST["age"]; 
if(is_numeric($age))
{

    $aErr="You have entered age";
}
else{
    $aErr= "enter ager";
}

echo "<br>";
$age = $_REQUEST["nid"]; 
if(is_numeric($nid))
{

    $nErr="You have entered nid";
}
else{
    $nErr= "enter nid";
}



echo "<br>";

if(isset($_REQUEST["Gender"]))
{

    $GenderErr= "You selected gender";
}
else{
    $GenderErr= "Please select your gender";
}

echo "<br>";

$password= $_REQUEST["password"]; 
$confirmpassword=$_REQUEST["confirmpassword"];

        if(empty($password) || strlen($password)<6)
        {
            $passwordErr=  "Please enter a valid password";
        }
        else if($password != $confirmpassword)
        {
            $passwordErr= "Password didn't match";
        }
        else
        {
            $passwordErr= "Password is valid";
        }
        if(move_uploaded_file($_FILES["myfile"]["tmp_name"], "../upload/".$_FILES["myfile"]["name"]))
         {
            $fileUpErr= "File is Uploaded";
         }
         else
         {
            $fileUpErr= "File Cannot be Uploaded";
         }

        $formdata = array(
            'uname'=>$uname,
            'Name'=> $name,
            'Email'=>$email,
            'PhoneNo'=> $number,
            'age'=>$age,
            'nid'=>$nid,
            'password'=>$password,
            'filename'=>$_FILES["myfile"]["name"] 
         );
         $existingdata = file_get_contents('sellerdata.json');
         
         $tempJSONdata = json_decode($existingdata);

         $tempJSONdata[] =$formdata;
        
         $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
         
        
         if(file_put_contents("sellerdata.json", $jsondata)) {
              echo "Data successfully Saved ";
              echo "<br>";
              echo "You can Login Now";
              echo "<html> <a href='../view/sellerlogin.php'> Click Here </a> </html>";
        
          }
         else 
         {
              echo "No data is saved";
         }
         

}
?>
