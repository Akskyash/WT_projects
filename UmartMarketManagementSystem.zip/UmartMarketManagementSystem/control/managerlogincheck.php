<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
}
$hasError=0;

$data = file_get_contents('managerdata.json');
$mydata = json_decode($data);


if(isset($_POST["Login"]))

{
     foreach($mydata as  $key => $udata)
     {
     
                    
               if($udata->uname==$_POST["uname"] && $udata->password==$_POST["pass"])
               {

                    $_SESSION["uname"]=$_POST["uname"];
                    $_SESSION["password"]=$_POST["pass"];
                    header("location: ../view/profile.php");
               }     

     }

     if(empty($_REQUEST["uname"])||(empty($_REQUEST["pass"])))
            {
                $usernameError= "Enter your user name and password !";
            }
            else{

                $hasError=1;
            }   



    if($hasError==1){
        $userPass_Error= "Your username or password is incorrect !";
    }
     

     echo "<h1>Your username or password is incorrect !<h1>";
          
}

?>
