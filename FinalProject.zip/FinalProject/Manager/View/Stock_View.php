<?php
//include "Search_View_Stock_Process.php";

//session_start();
?>

<!DOCTYPE html>
<html>
<body>
<font align="center" color="#32cd32" size="4" face="sans-serif">
    <h2 >Stock Details</h2>
</font>
    <form action="../Control/View_Stock_Process.php" method="post" enctype="multipart/form-data">

    <table border="1" width="650" align="center" cellspacing="3" cellpadding="8" bgcolor="#ffffff">
    <tr><td><img src="../Image/shop.jpg" size="420" width="650"></td></tr>

    <tr height="50px" bgcolor="#7cfc00"><td>
    <input type="submit" name="View" value="View Report" bgcolor="#7cfc00">

</td>
</tr>

       
</table>

</form>
</body>
</html>