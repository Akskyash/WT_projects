<?php include('../controller/cashiercontroller.php'); ?>


<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../css/cashier.css">
  <title>Register</title>
</head>
<body>
  <p align="right">
 
  <a href="logout.php" style=" color: #fff;padding: 10px 28px;background: red;text-decoration: none;font-weight: bold; " href="">Logout</a>
</p>
  <center>
  <h3>CASHIER page </h3>
  <form action="" method="post">
      <table >
       
        <tr>
          <a class="btn"style="margin: 0 6px;" href="my_account.php">MY ACOUNT</a>
          <a class="btn" style="margin: 0 6px;" href="contuctadmin.php">CONTACT to ADMIN</a>
          <a class="btn"style="margin: 0 6px;" href="stockreport.php">Stock report</a>
          <a class="btn"style="margin: 0 6px;" href="stockreportview.php">Stock report view</a>
          <a class="btn"style="margin: 0 6px;" href="sellsreport.php">seles report!</a>
          <a class="btn"style="margin: 0 6px;" href="sellrecorde.php">seles record!</a>
          <a class="btn"style="margin: 0 6px;" href="purchesrecorde.php">Purches record  </a>
          <a class="btn"style="margin: 0 6px;" href="purches.php">Purches view  </a>
          <a class="btn"style="margin: 0 6px;" href="supplyerpay.php">pay to supplier</a>
          <a class="btn"style="margin: 0 6px;" href="customarpay.php">Payment to customer </a>
          <a class="btn"style="margin: 0 6px;" href="othereexpence.php">Other expresses </a>
          <a class="btn"style="margin: 0 6px;" href="viewtansection.php">view Transection</a>
          
        </tr>
        
      </table>
  </form>
  <div class="imge">
    <img src="../img/cash.png">
  </div>
  </center>
 
</body>
</html>