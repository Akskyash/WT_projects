<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/cs.css">

</head>
<body>

<div class="header">
<img src="../images/Logo.png" width="100" height="80">
  <center>
  <h1>Umart Ecommerce Management System</h1>
  <h5>*Engaging more, Enlivening result*</h5>
  </center>
</div>
<div class="topnav">
  <a class="active" href="../view/Home.php">Home</a>
  <a href="../view/imagess.php">Images</a>
  <a href="../view/contact.php">Contact</a>
  <a href="../view/loginpanels.php" class="split">Login</a>
</div><br>

<div class="container">
  <img src="../images/p4.jpg" alt="Notebook" style="width:50%;">
  <div class="content">
    <h1>Asif Sharif Akash</h1>
    <p>ADMIN</p>
  </div>
</div>
<br>
<br>
<div class="container">
  <img src="../images/p2.jpg" alt="Notebook" style="width:50%;">
  <div class="content">
    <h1>Tasnia Tarannom Elma</h1>
    <p>MANAGER</p>
  </div>
</div>
<br>
<br>
<div class="container">
  <img src="../images/p3.jpg" alt="Notebook" style="width:50%;">
  <div class="content">
    <h1>Sadman Rafi</h1>
    <p>CASHIER</p>
  </div>
</div>
<br>
<br>
<div class="container">
  <img src="../images/p1.jpg" alt="Notebook" style="width:50%;">
  <div class="content">
    <h1>Asmaul Husna Jarin</h1>
    <p>SUPPLIER</p>
  </div>
</div>
</form>
</body>
</html>
