<html>
<img src="../images/Logo.png" width="120" height="100">
  <center>
    <head>
        <title>Home Page</title>
</head>
<body style="background-color:aqua;">
    <table>   
      <h1 style="color:blue">Login Pannels</h1>

        <tr><a href = "../ak/Homepage.php"><br><h2>Admin</h2></a><input type="image" src="../images/admin.jpg" height="150" width="150" ></br></tr>
        <td><tr><a href = "../Manager/View/LogIn.php"><br><h2>Manager</h2></a><input type="image" src="../images/manager.jpg" height="150" width="150" ></br></tr></td>
        <td><tr><a href = "../Cashier/view/login.php"><br><h2>Cashier</h2></a><input type="image" src="../images/buyer.jpg" height="150" width="150" ></br></tr></td>
        <td><tr><a href = "../Supplier/View/login.php"><br><h2>Supplier</h2></a><input type="image" src="../images/seller.jpg" height="150" width="150" ></br></tr></td>
        
</table>
</form>
</body>
</center> 
</html>

