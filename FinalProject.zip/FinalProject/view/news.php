<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/cs.css">

</head>
<body>

<div class="header">
<img src="../images/Logo.png" width="100" height="80">
  <center>
  <h1>Umart Ecommerce Management System</h1>
  <h5>*Engaging more, Enlivening result*</h5>
  </center>
</div>
<div class="topnav">
  <a class="active" href="../view/Home.php">Home</a>
  <a href="../view/news.php">News</a>
  <a href="../view/imagess.php">Images</a>
  <a href="../view/contact.php">Contact</a>
  <a href="../view/hello.php" class="split">Login</a>
</div><br>



</form>
</body>
</html>
