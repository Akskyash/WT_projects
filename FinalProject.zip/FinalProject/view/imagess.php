<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/cs.css">

</head>
<body>

<div class="header">
<img src="../images/Logo.png" width="100" height="80">
  <center>
  <h1>Umart Ecommerce Management System</h1>
  <h5>*Engaging more, Enlivening result*</h5>
  </center>
</div>
<div class="topnav">
  <a class="active" href="../view/Home.php">Home</a>
  <a href="../view/imagess.php">Images</a>
  <a href="../view/contact.php">Contact</a>
  <a href="../view/loginpanels.php" class="split">Login</a>
</div><br>
<table>
  <td><tr>
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <img src="../images/m1.jpg" alt="Paris" style="width:300px;height:200px">
    </div>
    <div class="flip-box-back">
      <h2>Fruits/Vegetables</h2>
      <p>Fresh Fruits & Vegetables</p>
    </div>
  </div>
</div>

<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <img src="../images/m2.jpg" alt="Paris" style="width:300px;height:200px" >
    </div>
    <div class="flip-box-back">
      <h2>Grocery</h2>
      <p>Hand made spices</p>
    </div>
  </div>
</div>

<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <img src="../images/m3.jpg" alt="Paris" style="width:300px;height:200px">
    </div>
    <div class="flip-box-back">
      <h2>Electronic Products</h2>
      <p>Safe & Sound</p>
    </div>
  </div>
</div>

<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <img src="../images/m4.jpg" alt="Paris" style="width:300px;height:200px">
    </div>
    <div class="flip-box-back">
      <h2>Homeline Appliances</h2>
      <p>Home sweet Home</p>
    </div>
  </div>
</div>
</tr></td>
</table>
</form>
</body>
</html>
