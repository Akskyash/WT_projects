<?php require "../Control/ordercheck.php" ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<link rel="stylesheet" type="text/css" href="../public/css/Supplierlogin.css">

</head>
<Body>
 <div class="contact-card">

<div class="contact-card2">
  <p>check orders by serching product name and you can also search by clicking search order.</p>
</div>
<font align="center" size="" face="Verdana">
<h3>Check Orders </h3><hr>
 <hr>
</div>
<table border="0" width="100%" align="center" cellspacing="2" cellpadding="2" >
 		
 	<tr><td></td>
 		<td width="50%" >
            <a href="../View/Searchorder.php">Search a single Product</a>&nbsp;
            <a href="../View/SupplierDashboard.php">Supplier Dashboard</a>&nbsp;
             <a href="ContactAdmin.php">Contact Admin </a>&nbsp;
             

</td><td></td>
</tr>
</table>

</Body>
</html>