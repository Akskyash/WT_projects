<?php require "../Control/logoutcheck.php" ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
</head>
<Body>
	<font align="center"  size="5" face="Verdana">
<h2>logout page </h2>
 <hr>

<a href="../View/login.php" align="right">login</a>

</Body>
</html>