<!DOCTYPE html>
<html>
<head>
<title>Verify Seller</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<navbar class="menu-bar" style="float: right;">
          <span>
         <a href="Homepage.php" style="color:indianred;" > Home </a>
          <span>&nbsp;|&nbsp;</span>
         <span>&nbsp;</span>
         <a href="Login.php" style="color:indianred;" class="option">Login</a>
         <span>&nbsp;|&nbsp;</span>
         <span>&nbsp;</span>
        <a href="Signup.php" style="color:indianred;" class="option">Signup</a>
</navbar>
<div class="container">
  <img src="Picture/jko.jpg" alt="Cinque Terre" width="1000" height="300">
  <div class="center">Verify Seller Successfully</div>
</div>

</body>
</html>