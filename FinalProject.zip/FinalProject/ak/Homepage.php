<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Homepage</title>

</head>
<body>
	<center>
<table style="background-color:#add8e6;width: 100%;height: 5%;">
	<tr>
		<td>
			<h1 style="text-align: center;color: darkred;">&nbsp;&nbsp;&nbsp;Umart Market Management System(Admin Area)</h1>
		</td>
		<td align="right">
			<p><a href="Homepage.php" style="color:indianred;">Home</a></p>
			
		</td>
		
	</tr>
</table>
<br>
<h2 style="text-align:right;"><br><b><a href="Login.php" style="color:#7CB9E8;">Login</a></b>
			&nbsp;&nbsp;<a href="Signup.php" style="color:#7CB9E8;">Signup</a>&nbsp;&nbsp;</h2>
			<br>
<div style="background-image:url('Picture/Umart.jpg');width: 700px;height:400px;">
</div>
<br>
<div style="height:200px;width:1490px;border:1px solid;margin:auto;background-color:grey;">
	 	&nbsp;<h1 style="color: white;text-align: center;">&nbsp;&nbsp;&nbsp;Engaging more, Enlivening result</h1>
	 	<p style="color: white;text-align: right;">Contact Us&nbsp;&nbsp;&nbsp;<br>01317545484,&nbsp;&nbsp;&nbsp;01960424642&nbsp;&nbsp;&nbsp;<br>Email: service@gmail.com&nbsp;&nbsp;&nbsp;<br>***Thank you***&nbsp;&nbsp;&nbsp;</p>
</div>
</center>
</body>
</html>